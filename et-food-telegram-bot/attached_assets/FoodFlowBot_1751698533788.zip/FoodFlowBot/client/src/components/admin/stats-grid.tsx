import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown } from "lucide-react";

interface StatsData {
  totalOrders: number;
  revenue: number;
  activeUsers: number;
  pendingOrders: number;
}

export function StatsGrid() {
  const { data: stats, isLoading } = useQuery<StatsData>({
    queryKey: ["/api/stats"],
  });

  const statCards = [
    {
      title: "Total Orders",
      value: stats?.totalOrders || 0,
      change: "+12%",
      trend: "up",
      icon: "📋",
      color: "primary"
    },
    {
      title: "Revenue",
      value: `$${stats?.revenue?.toFixed(2) || '0.00'}`,
      change: "+8%",
      trend: "up",
      icon: "💰",
      color: "success"
    },
    {
      title: "Active Users",
      value: stats?.activeUsers || 0,
      change: "+5%",
      trend: "up",
      icon: "👥",
      color: "accent"
    },
    {
      title: "Pending Orders",
      value: stats?.pendingOrders || 0,
      change: "Need attention",
      trend: "neutral",
      icon: "⏰",
      color: "warning"
    }
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-8 w-16" />
                  <Skeleton className="h-4 w-24" />
                </div>
                <Skeleton className="h-12 w-12 rounded-xl" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => (
        <Card key={index}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm font-medium">
                  {stat.title}
                </p>
                <p className="text-2xl font-bold text-foreground">
                  {stat.value}
                </p>
                <p className={`text-sm flex items-center space-x-1 ${
                  stat.trend === "up" ? "text-green-600" :
                  stat.trend === "down" ? "text-red-600" :
                  "text-yellow-600"
                }`}>
                  {stat.trend === "up" && <TrendingUp className="h-3 w-3" />}
                  {stat.trend === "down" && <TrendingDown className="h-3 w-3" />}
                  <span>{stat.change}</span>
                </p>
              </div>
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                stat.color === "primary" ? "bg-primary/10" :
                stat.color === "success" ? "bg-green-100 dark:bg-green-900" :
                stat.color === "accent" ? "bg-blue-100 dark:bg-blue-900" :
                "bg-yellow-100 dark:bg-yellow-900"
              }`}>
                <span className="text-xl">{stat.icon}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
