import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Minus, Plus, MapPin, X } from "lucide-react";
import type { FoodItem } from "@shared/schema";

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedItem: FoodItem | null;
}

export function OrderModal({ isOpen, onClose, selectedItem }: OrderModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await apiRequest("POST", "/api/orders", orderData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Order placed successfully!",
        description: "Your order has been received and is being processed.",
      });
      onClose();
      resetForm();
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
    onError: (error) => {
      toast({
        title: "Order failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setQuantity(1);
    setPhone("");
    setAddress("");
    setPaymentMethod("cash");
    setLocation(null);
  };

  const shareLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          toast({
            title: "Location shared",
            description: "Your location has been captured successfully.",
          });
        },
        (error) => {
          toast({
            title: "Location error",
            description: "Unable to get your location. Please enter address manually.",
            variant: "destructive",
          });
        }
      );
    } else {
      toast({
        title: "Location not supported",
        description: "Your browser doesn't support location sharing.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedItem) return;

    const subtotal = Number(selectedItem.price) * quantity;
    const deliveryFee = 2.50;
    const total = subtotal + deliveryFee;

    const orderData = {
      customerPhone: phone,
      deliveryAddress: address,
      paymentMethod,
      subtotal: subtotal.toString(),
      deliveryFee: deliveryFee.toString(),
      total: total.toString(),
      location,
      orderItems: [
        {
          foodItemId: selectedItem.id,
          quantity,
          priceAtTime: selectedItem.price,
        },
      ],
    };

    createOrderMutation.mutate(orderData);
  };

  if (!selectedItem) return null;

  const subtotal = Number(selectedItem.price) * quantity;
  const deliveryFee = 2.50;
  const total = subtotal + deliveryFee;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Place Order</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Selected Item Display */}
          <div className="bg-muted rounded-xl p-4 flex items-center space-x-4">
            {selectedItem.imageUrl ? (
              <img
                src={selectedItem.imageUrl}
                alt={selectedItem.name}
                className="w-16 h-16 rounded-lg object-cover"
              />
            ) : (
              <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center">
                <span className="text-2xl">🍽️</span>
              </div>
            )}
            <div className="flex-1">
              <h3 className="font-semibold">{selectedItem.name}</h3>
              <p className="text-primary font-bold">${selectedItem.price}</p>
            </div>
          </div>

          {/* Quantity Selection */}
          <div>
            <Label className="block text-sm font-medium mb-2">Quantity</Label>
            <div className="flex items-center space-x-4">
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="text-xl font-semibold min-w-[2rem] text-center">
                {quantity}
              </span>
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setQuantity(quantity + 1)}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Phone Number */}
          <div>
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="+1 (555) 123-4567"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
            />
          </div>

          {/* Delivery Location */}
          <div>
            <Label htmlFor="address">Delivery Location</Label>
            <div className="space-y-2">
              <Textarea
                id="address"
                placeholder="Enter your full address..."
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                rows={3}
                required
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={shareLocation}
                className="w-full bg-accent/10 text-accent border-accent/20 hover:bg-accent/20"
              >
                <MapPin className="h-4 w-4 mr-2" />
                Share My Location
              </Button>
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <Label>Payment Method</Label>
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
              <div className="flex items-center space-x-2 p-3 border rounded-xl">
                <RadioGroupItem value="cash" id="cash" />
                <Label htmlFor="cash" className="flex items-center space-x-3 cursor-pointer">
                  <span className="text-xl">💵</span>
                  <span className="font-medium">Cash on Delivery</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-xl">
                <RadioGroupItem value="telebirr" id="telebirr" />
                <Label htmlFor="telebirr" className="flex items-center space-x-3 cursor-pointer">
                  <span className="text-xl">📱</span>
                  <span className="font-medium">Telebirr</span>
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Order Summary */}
          <div className="bg-muted rounded-xl p-4 space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="font-medium">${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Delivery Fee</span>
              <span className="font-medium">${deliveryFee.toFixed(2)}</span>
            </div>
            <div className="border-t pt-2 flex justify-between">
              <span className="font-semibold">Total</span>
              <span className="font-bold text-primary text-lg">${total.toFixed(2)}</span>
            </div>
          </div>

          {/* Place Order Button */}
          <Button
            type="submit"
            className="w-full"
            size="lg"
            disabled={createOrderMutation.isPending}
          >
            {createOrderMutation.isPending ? (
              "Placing Order..."
            ) : (
              <>
                <span className="mr-2">✓</span>
                Place Order
              </>
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
