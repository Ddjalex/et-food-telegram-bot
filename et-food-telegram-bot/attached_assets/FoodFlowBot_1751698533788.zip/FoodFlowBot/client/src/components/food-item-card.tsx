import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Clock, Heart, Plus } from "lucide-react";
import type { FoodItem } from "@shared/schema";

interface FoodItemCardProps {
  item: FoodItem;
  onOrderClick: (item: FoodItem) => void;
}

export function FoodItemCard({ item, onOrderClick }: FoodItemCardProps) {
  const defaultImages = [
    "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400",
    "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400",
    "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400",
    "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?w=400",
  ];

  const imageUrl = item.imageUrl || defaultImages[item.id % defaultImages.length];

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative">
        <img
          src={imageUrl}
          alt={item.name}
          className="w-full h-48 object-cover"
          onError={(e) => {
            e.currentTarget.src = defaultImages[0];
          }}
        />
        <div className="absolute top-3 left-3">
          <Badge 
            className={item.isAvailable ? "bg-success text-white" : "bg-muted text-muted-foreground"}
          >
            {item.isAvailable ? "Available" : "Unavailable"}
          </Badge>
        </div>
        <div className="absolute top-3 right-3">
          <Button
            size="icon"
            variant="ghost"
            className="w-8 h-8 bg-white/80 backdrop-blur-sm rounded-full hover:bg-white"
          >
            <Heart className="h-4 w-4 text-muted-foreground hover:text-red-500" />
          </Button>
        </div>
        <div className="absolute bottom-3 right-3">
          <Badge className="bg-white/90 backdrop-blur-sm text-primary font-bold text-lg px-3 py-1">
            ${item.price}
          </Badge>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-1">{item.name}</h3>
        <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
          {item.description}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
              <span className="text-sm font-medium">{item.rating || "4.5"}</span>
              <span className="text-xs text-muted-foreground">({item.reviewCount || 0})</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">{item.deliveryTime}</span>
            </div>
          </div>
          
          <Button
            onClick={() => onOrderClick(item)}
            disabled={!item.isAvailable}
            size="sm"
            className="font-medium"
          >
            <Plus className="h-4 w-4 mr-2" />
            Order
          </Button>
        </div>
      </div>
    </div>
  );
}
