import type { Category } from "@shared/schema";

interface CategoryGridProps {
  categories: Category[];
  selectedCategory: number | null;
  onCategorySelect: (categoryId: number | null) => void;
}

const categoryIcons: Record<string, string> = {
  pizza: "🍕",
  burgers: "🍔",
  sushi: "🍱",
  desserts: "🍰",
  drinks: "🥤",
  salads: "🥗",
  default: "🍽️"
};

const categoryColors = [
  "from-orange-500 to-red-600",
  "from-yellow-500 to-orange-600", 
  "from-teal-500 to-cyan-600",
  "from-pink-500 to-purple-600",
  "from-blue-500 to-indigo-600",
  "from-green-500 to-emerald-600"
];

export function CategoryGrid({ categories, selectedCategory, onCategorySelect }: CategoryGridProps) {
  return (
    <div className="grid grid-cols-4 gap-3">
      {categories.map((category, index) => {
        const isSelected = selectedCategory === category.id;
        const icon = categoryIcons[category.slug] || categoryIcons.default;
        const colorClass = categoryColors[index % categoryColors.length];
        
        return (
          <div
            key={category.id}
            className={`text-center cursor-pointer hover:scale-105 transition-transform ${
              isSelected ? "opacity-100" : "opacity-90 hover:opacity-100"
            }`}
            onClick={() => onCategorySelect(isSelected ? null : category.id)}
          >
            <div className={`w-16 h-16 bg-gradient-to-br ${colorClass} rounded-xl flex items-center justify-center mx-auto mb-2 shadow-lg ${
              isSelected ? "ring-2 ring-primary ring-offset-2" : ""
            }`}>
              <span className="text-xl">{icon}</span>
            </div>
            <span className={`text-xs font-medium ${
              isSelected ? "text-primary" : "text-foreground"
            }`}>
              {category.name}
            </span>
          </div>
        );
      })}
    </div>
  );
}
