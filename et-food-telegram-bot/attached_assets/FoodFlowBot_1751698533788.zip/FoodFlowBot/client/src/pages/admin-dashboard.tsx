import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { StatsGrid } from "@/components/admin/stats-grid";
import { OrdersTable } from "@/components/admin/orders-table";
import { MenuManagement } from "@/components/admin/menu-management";
import { LogOut, Shield } from "lucide-react";

export default function AdminDashboard() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("dashboard");

  // Check if user is admin
  if (!user?.isAdmin) {
    setLocation("/auth");
    return null;
  }

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    setLocation("/");
  };

  const exportOrders = async () => {
    try {
      const response = await fetch("/api/orders/export", {
        credentials: "include",
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'orders.csv';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Header */}
      <div className="bg-secondary text-secondary-foreground p-6 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Shield className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Admin Dashboard</h1>
              <p className="text-secondary-foreground/70 text-sm">FoodBot Management</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="text-white hover:bg-white/20"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      {/* Admin Navigation */}
      <div className="bg-background border-b border-border sticky top-20 z-10">
        <div className="max-w-7xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="h-12 bg-transparent border-0 rounded-0 w-full justify-start">
              <TabsTrigger
                value="dashboard"
                className="h-full rounded-0 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-primary/5"
              >
                <span className="mr-2">📊</span>Dashboard
              </TabsTrigger>
              <TabsTrigger
                value="orders"
                className="h-full rounded-0 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-primary/5"
              >
                <span className="mr-2">📋</span>Orders
              </TabsTrigger>
              <TabsTrigger
                value="menu"
                className="h-full rounded-0 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-primary/5"
              >
                <span className="mr-2">🍽️</span>Menu
              </TabsTrigger>
              <TabsTrigger
                value="settings"
                className="h-full rounded-0 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-primary/5"
              >
                <span className="mr-2">⚙️</span>Settings
              </TabsTrigger>
            </TabsList>

            <div className="p-6">
              <TabsContent value="dashboard" className="space-y-8">
                <StatsGrid />
                <OrdersTable />
              </TabsContent>

              <TabsContent value="orders" className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Order Management</h2>
                  <Button onClick={exportOrders} variant="outline">
                    <span className="mr-2">📥</span>Export CSV
                  </Button>
                </div>
                <OrdersTable showAllOrders />
              </TabsContent>

              <TabsContent value="menu" className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Menu Management</h2>
                </div>
                <MenuManagement />
              </TabsContent>

              <TabsContent value="settings" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>System Settings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      System settings and configuration options will be available here.
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
