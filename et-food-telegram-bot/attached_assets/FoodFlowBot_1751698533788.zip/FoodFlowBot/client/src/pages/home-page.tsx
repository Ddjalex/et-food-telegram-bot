import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, ShoppingCart, User, MapPin, Headphones, Heart, Receipt } from "lucide-react";
import { Link, useLocation } from "wouter";
import { CategoryGrid } from "@/components/category-grid";
import { FoodItemCard } from "@/components/food-item-card";
import { OrderModal } from "@/components/order-modal";
import { useAuth } from "@/hooks/use-auth";
import type { FoodItem, Category } from "@shared/schema";

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedItem, setSelectedItem] = useState<FoodItem | null>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: foodItems, isLoading: foodItemsLoading } = useQuery<FoodItem[]>({
    queryKey: ["/api/food-items", selectedCategory],
    queryFn: async () => {
      const url = selectedCategory 
        ? `/api/food-items?categoryId=${selectedCategory}`
        : "/api/food-items";
      const response = await fetch(url);
      return response.json();
    },
  });

  const filteredItems = foodItems?.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.description.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handleOrderClick = (item: FoodItem) => {
    setSelectedItem(item);
    setIsOrderModalOpen(true);
  };

  const shareLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          console.log('Location shared:', position.coords);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  };

  return (
    <div className="max-w-md mx-auto bg-background min-h-screen relative overflow-hidden">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
            <span className="text-lg">🍽️</span>
          </div>
          <div>
            <h1 className="font-bold text-lg">FoodBot</h1>
            <p className="text-xs opacity-90">Fast Food Delivery</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white"
            onClick={() => setLocation(user ? "/orders" : "/auth")}
          >
            <User className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="relative p-2 rounded-full bg-white/20 hover:bg-white/30 text-white"
          >
            <ShoppingCart className="h-4 w-4" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-accent text-accent-foreground text-xs p-0 flex items-center justify-center">
              0
            </Badge>
          </Button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-background border-b border-border sticky top-16 z-40">
        <div className="flex overflow-x-auto scrollbar-hide">
          <button className="flex-shrink-0 px-4 py-3 text-sm font-medium text-primary border-b-2 border-primary bg-primary/5">
            <span className="mr-2">🏠</span>Home
          </button>
          <Link href="/orders" className="flex-shrink-0 px-4 py-3 text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            <Receipt className="inline mr-2 h-4 w-4" />Orders
          </Link>
          <button className="flex-shrink-0 px-4 py-3 text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            <Heart className="inline mr-2 h-4 w-4" />Favorites
          </button>
          <Link href="/auth" className="flex-shrink-0 px-4 py-3 text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            <User className="inline mr-2 h-4 w-4" />Profile
          </Link>
        </div>
      </div>

      {/* Categories */}
      <div className="p-4 bg-background">
        <h2 className="font-semibold text-lg mb-3">Food Categories</h2>
        {categoriesLoading ? (
          <div className="grid grid-cols-4 gap-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="text-center">
                <Skeleton className="w-16 h-16 rounded-xl mx-auto mb-2" />
                <Skeleton className="h-3 w-12 mx-auto" />
              </div>
            ))}
          </div>
        ) : (
          <CategoryGrid
            categories={categories || []}
            selectedCategory={selectedCategory}
            onCategorySelect={setSelectedCategory}
          />
        )}
      </div>

      {/* Search */}
      <div className="px-4 pb-4 bg-background">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search for food..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-muted border-0 focus:ring-2 focus:ring-primary"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        </div>
      </div>

      {/* Food Items */}
      <div className="px-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-lg">
            {selectedCategory ? "Category Items" : "Popular Items"}
          </h2>
          {selectedCategory && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedCategory(null)}
              className="text-primary"
            >
              View All
            </Button>
          )}
        </div>

        {foodItemsLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-card rounded-xl shadow-sm border border-border overflow-hidden">
                <Skeleton className="w-full h-48" />
                <div className="p-4 space-y-2">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No food items found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredItems.map((item) => (
              <FoodItemCard
                key={item.id}
                item={item}
                onOrderClick={handleOrderClick}
              />
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="fixed bottom-20 right-4 space-y-3">
        <Button
          size="icon"
          className="w-12 h-12 bg-accent text-accent-foreground rounded-full shadow-lg hover:shadow-xl"
          onClick={shareLocation}
          title="Share Location"
        >
          <MapPin className="h-5 w-5" />
        </Button>
        <Button
          size="icon"
          className="w-12 h-12 bg-secondary text-secondary-foreground rounded-full shadow-lg hover:shadow-xl"
          title="Contact Support"
        >
          <Headphones className="h-5 w-5" />
        </Button>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-background border-t border-border px-4 py-2">
        <div className="flex items-center justify-around">
          <button className="flex flex-col items-center space-y-1 py-2 text-primary">
            <span className="text-lg">🏠</span>
            <span className="text-xs font-medium">Home</span>
          </button>
          <Link href="/orders" className="flex flex-col items-center space-y-1 py-2 text-muted-foreground hover:text-primary transition-colors">
            <Receipt className="h-5 w-5" />
            <span className="text-xs font-medium">Orders</span>
          </Link>
          <button className="flex flex-col items-center space-y-1 py-2 text-muted-foreground hover:text-primary transition-colors">
            <Heart className="h-5 w-5" />
            <span className="text-xs font-medium">Favorites</span>
          </button>
          <Link href="/auth" className="flex flex-col items-center space-y-1 py-2 text-muted-foreground hover:text-primary transition-colors">
            <User className="h-5 w-5" />
            <span className="text-xs font-medium">Profile</span>
          </Link>
        </div>
      </div>

      <div className="h-20"></div>

      {/* Order Modal */}
      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        selectedItem={selectedItem}
      />
    </div>
  );
}
