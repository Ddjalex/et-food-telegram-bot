import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Minus, Plus, ShoppingCart, ArrowLeft } from "lucide-react";
import type { FoodItem, Category } from "@shared/schema";

// Telegram WebApp interface (simplified)
declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        ready(): void;
        close(): void;
        expand(): void;
        MainButton: {
          text: string;
          show(): void;
          hide(): void;
          onClick(callback: () => void): void;
        };
        initDataUnsafe: {
          user?: {
            id: number;
            username?: string;
            first_name?: string;
          };
        };
      };
    };
  }
}

interface CartItem extends FoodItem {
  quantity: number;
}

export default function TelegramWebApp() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [showOrderForm, setShowOrderForm] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize Telegram WebApp
  useEffect(() => {
    if (window.Telegram?.WebApp) {
      const webapp = window.Telegram.WebApp;
      webapp.ready();
      webapp.expand();
      
      // Set up main button
      webapp.MainButton.text = "Place Order";
      webapp.MainButton.onClick(() => {
        if (cart.length > 0) {
          setShowOrderForm(true);
        }
      });
    }
  }, []);

  // Update main button based on cart
  useEffect(() => {
    if (window.Telegram?.WebApp) {
      const webapp = window.Telegram.WebApp;
      if (cart.length > 0) {
        const total = cart.reduce((sum, item) => sum + (Number(item.price) * item.quantity), 0);
        webapp.MainButton.text = `Order (${cart.length}) - $${total.toFixed(2)}`;
        webapp.MainButton.show();
      } else {
        webapp.MainButton.hide();
      }
    }
  }, [cart]);

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Failed to fetch categories");
      return response.json();
    },
  });

  const { data: foodItems, isLoading: foodItemsLoading } = useQuery<FoodItem[]>({
    queryKey: ["/api/food-items", selectedCategory],
    queryFn: async () => {
      const url = selectedCategory 
        ? `/api/food-items?categoryId=${selectedCategory}`
        : "/api/food-items";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch food items");
      return response.json();
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(orderData),
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || "Failed to create order");
      }
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Order placed successfully!",
        description: `Order #${data.id} has been received.`,
      });
      setCart([]);
      setShowOrderForm(false);
      
      // Close Telegram WebApp
      if (window.Telegram?.WebApp) {
        window.Telegram.WebApp.close();
      }
    },
    onError: (error) => {
      toast({
        title: "Order failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addToCart = (item: FoodItem) => {
    setCart(prev => {
      const existing = prev.find(cartItem => cartItem.id === item.id);
      if (existing) {
        return prev.map(cartItem =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: number, change: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.id === id) {
          const newQuantity = item.quantity + change;
          return newQuantity > 0 ? { ...item, quantity: newQuantity } : item;
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (cart.length === 0) return;

    const subtotal = cart.reduce((sum, item) => sum + (Number(item.price) * item.quantity), 0);
    const deliveryFee = 2.50;
    const total = subtotal + deliveryFee;

    const orderData = {
      customerPhone: phone,
      deliveryAddress: address,
      paymentMethod,
      subtotal: subtotal.toString(),
      deliveryFee: deliveryFee.toString(),
      total: total.toString(),
      orderItems: cart.map(item => ({
        foodItemId: item.id,
        quantity: item.quantity,
        priceAtTime: item.price,
      })),
    };

    createOrderMutation.mutate(orderData);
  };

  if (showOrderForm) {
    const subtotal = cart.reduce((sum, item) => sum + (Number(item.price) * item.quantity), 0);
    const deliveryFee = 2.50;
    const total = subtotal + deliveryFee;

    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-md mx-auto">
          <div className="flex items-center mb-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowOrderForm(false)}
              className="mr-3"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-xl font-bold">Complete Order</h1>
          </div>

          <form onSubmit={handleSubmitOrder} className="space-y-6">
            {/* Order Summary */}
            <div className="bg-muted rounded-xl p-4">
              <h3 className="font-semibold mb-3">Order Summary</h3>
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between items-center mb-2">
                  <span className="text-sm">{item.name} x{item.quantity}</span>
                  <span className="font-medium">${(Number(item.price) * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="border-t pt-2 mt-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery</span>
                  <span>${deliveryFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span className="text-primary">${total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Contact Info */}
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
            </div>

            {/* Delivery Address */}
            <div>
              <Label htmlFor="address">Delivery Address</Label>
              <Textarea
                id="address"
                placeholder="Enter your full address..."
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                rows={3}
                required
              />
            </div>

            {/* Payment Method */}
            <div>
              <Label>Payment Method</Label>
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                <div className="flex items-center space-x-2 p-3 border rounded-xl">
                  <RadioGroupItem value="cash" id="cash" />
                  <Label htmlFor="cash" className="flex items-center space-x-3 cursor-pointer">
                    <span className="text-xl">💵</span>
                    <span className="font-medium">Cash on Delivery</span>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-3 border rounded-xl">
                  <RadioGroupItem value="telebirr" id="telebirr" />
                  <Label htmlFor="telebirr" className="flex items-center space-x-3 cursor-pointer">
                    <span className="text-xl">📱</span>
                    <span className="font-medium">Telebirr</span>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={createOrderMutation.isPending}
            >
              {createOrderMutation.isPending ? (
                "Placing Order..."
              ) : (
                `Place Order - $${total.toFixed(2)}`
              )}
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 sticky top-0 z-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
              <span className="text-lg">🍽️</span>
            </div>
            <div>
              <h1 className="font-bold text-lg">FoodBot</h1>
              <p className="text-xs opacity-90">Order from Telegram</p>
            </div>
          </div>
          {cart.length > 0 && (
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant="ghost"
                className="relative p-2 rounded-full bg-white/20 hover:bg-white/30 text-white"
                onClick={() => setShowOrderForm(true)}
              >
                <ShoppingCart className="h-4 w-4" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-accent text-accent-foreground text-xs p-0 flex items-center justify-center">
                  {cart.reduce((sum, item) => sum + item.quantity, 0)}
                </Badge>
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Categories */}
      <div className="p-4">
        <h2 className="font-semibold text-lg mb-3">Food Categories</h2>
        {categoriesLoading ? (
          <div className="grid grid-cols-3 gap-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="text-center">
                <Skeleton className="w-16 h-16 rounded-xl mx-auto mb-2" />
                <Skeleton className="h-3 w-12 mx-auto" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            <div
              className={`text-center cursor-pointer p-3 rounded-xl transition-all ${
                selectedCategory === null ? "bg-primary/10 ring-2 ring-primary" : "hover:bg-muted"
              }`}
              onClick={() => setSelectedCategory(null)}
            >
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-lg">🍽️</span>
              </div>
              <span className="text-xs font-medium">All</span>
            </div>
            {categories?.map((category) => (
              <div
                key={category.id}
                className={`text-center cursor-pointer p-3 rounded-xl transition-all ${
                  selectedCategory === category.id ? "bg-primary/10 ring-2 ring-primary" : "hover:bg-muted"
                }`}
                onClick={() => setSelectedCategory(category.id)}
              >
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                  <span className="text-lg">{category.icon}</span>
                </div>
                <span className="text-xs font-medium">{category.name}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Food Items */}
      <div className="px-4 space-y-4">
        <h2 className="font-semibold text-lg">
          {selectedCategory ? "Category Items" : "All Items"}
        </h2>

        {foodItemsLoading ? (
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-card rounded-xl border border-border p-4">
                <div className="flex space-x-4">
                  <Skeleton className="w-16 h-16 rounded-lg" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-5 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : foodItems?.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No food items available</p>
          </div>
        ) : (
          <div className="space-y-3">
            {foodItems?.map((item) => {
              const cartItem = cart.find(cartItem => cartItem.id === item.id);
              return (
                <div key={item.id} className="bg-card rounded-xl border border-border p-4">
                  <div className="flex space-x-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-2xl">🍽️</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-base mb-1">{item.name}</h3>
                      <p className="text-muted-foreground text-sm mb-2 line-clamp-2">
                        {item.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-primary">${item.price}</span>
                        {cartItem ? (
                          <div className="flex items-center space-x-3">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateQuantity(item.id, -1)}
                              className="h-8 w-8 p-0"
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="font-semibold min-w-[1.5rem] text-center">
                              {cartItem.quantity}
                            </span>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateQuantity(item.id, 1)}
                              className="h-8 w-8 p-0"
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => addToCart(item)}
                            disabled={!item.isAvailable}
                          >
                            <Plus className="h-4 w-4 mr-1" />
                            Add
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="h-24"></div>
    </div>
  );
}