# Telegram Food Delivery Bot System

## Overview

This is a comprehensive Telegram food delivery bot system featuring a full-stack web application, Telegram bot integration, and admin dashboard. Built with React, Express.js, PostgreSQL, and the Telegram Bot API, it provides a complete food ordering platform accessible both through web browsers and directly within Telegram.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and production builds
- **Styling**: Tailwind CSS with CSS variables for theming
- **Component Library**: Radix UI primitives with shadcn/ui components
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Passport.js with local strategy and session-based auth
- **Session Storage**: PostgreSQL session store with connect-pg-simple
- **File Uploads**: Multer for handling image uploads
- **API**: RESTful API with JSON responses

### Database Architecture
- **ORM**: Drizzle ORM with TypeScript-first approach
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema**: Shared schema definitions between client and server
- **Migrations**: Drizzle Kit for database migrations

## Key Components

### Telegram Bot Integration
- **Bot Commands**: `/start`, `/menu`, `/orders`, `/help` for customer interaction
- **Mini Web App**: Full ordering interface accessible within Telegram
- **Location Sharing**: GPS location integration for delivery
- **Order Notifications**: Real-time updates to customers and admins
- **User Registration**: Automatic account creation for Telegram users
- **Payment Methods**: Cash on delivery and Telebirr integration

### Database Schema
- **Users**: Authentication and user management with admin roles and Telegram ID support
- **Categories**: Food item categorization with icons and slugs
- **Food Items**: Menu items with pricing, descriptions, and availability
- **Orders**: Complete order management with status tracking and location data
- **Order Items**: Individual items within orders with quantities
- **Favorites**: User's favorite food items

### Authentication System
- Session-based authentication using Passport.js
- Password hashing with Node.js crypto (scrypt)
- Protected routes for admin functionality
- User registration and login with phone and Telegram ID support
- Telegram user auto-registration

### API Endpoints
- `/api/auth/*` - Authentication routes (login, register, logout)
- `/api/categories` - Category management
- `/api/food-items` - Menu item management
- `/api/orders` - Order creation and management
- `/api/stats` - Admin dashboard statistics
- `/api/telegram/*` - Telegram webhook and user management
- `/telegram` - Telegram Mini Web App interface

### UI Components
- Responsive design with mobile-first approach
- Category grid with emoji icons and gradient backgrounds
- Food item cards with images, ratings, and availability status
- Order modal with quantity selection and delivery details
- Admin dashboard with statistics and order management
- Telegram Mini App optimized for mobile browsers

## Data Flow

1. **User Registration/Login**: Users authenticate through the auth system
2. **Menu Browsing**: Categories and food items are fetched from the API
3. **Order Creation**: Users select items, add quantities, and provide delivery details
4. **Order Processing**: Orders are stored with status tracking
5. **Admin Management**: Admins can manage menu items, orders, and view statistics

## External Dependencies

### Frontend Dependencies
- React ecosystem (React, ReactDOM, React Query)
- UI libraries (Radix UI, Lucide icons)
- Form handling (React Hook Form, Hookform Resolvers)
- Utility libraries (clsx, class-variance-authority, date-fns)

### Backend Dependencies
- Express.js and middleware
- Database (Drizzle ORM, Neon serverless client)
- Authentication (Passport.js, express-session)
- File handling (Multer)
- Validation (Zod)

### Development Dependencies
- Build tools (Vite, TypeScript, ESBuild)
- Styling (Tailwind CSS, PostCSS)
- Development utilities (TSX for server development)

## Deployment Strategy

### Production Build
- Client: Vite builds optimized React bundle to `dist/public`
- Server: ESBuild bundles Express server to `dist/index.js`
- Assets: Static files served from the Express server

### Environment Configuration
- Database connection via `DATABASE_URL` environment variable
- Session secret via `SESSION_SECRET` environment variable
- File uploads stored in `uploads/` directory

### Development Setup
- Hot module replacement with Vite
- Server auto-restart with TSX
- Database schema synchronization with Drizzle

## Changelog

```
Changelog:
- July 05, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```