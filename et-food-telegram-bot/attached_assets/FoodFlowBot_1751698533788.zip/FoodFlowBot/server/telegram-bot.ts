import TelegramBot from 'node-telegram-bot-api';
import { storage } from './storage';
import type { Category, FoodItem } from '@shared/schema';

interface TelegramBotConfig {
  token: string;
  webAppUrl: string;
}

export class FoodDeliveryBot {
  private bot: TelegramBot;
  private webAppUrl: string;

  constructor(config: TelegramBotConfig) {
    this.bot = new TelegramBot(config.token, { polling: true });
    this.webAppUrl = config.webAppUrl;
    this.setupCommands();
    this.setupHandlers();
  }

  private setupCommands() {
    // Set bot commands
    this.bot.setMyCommands([
      { command: 'start', description: 'Start ordering food' },
      { command: 'menu', description: 'View food menu' },
      { command: 'orders', description: 'View your orders' },
      { command: 'help', description: 'Get help' }
    ]);
  }

  private setupHandlers() {
    // Start command
    this.bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from?.id;
      const username = msg.from?.username;

      // Register or update user
      if (userId && username) {
        try {
          let user = await storage.getUserByTelegramId(userId.toString());
          if (!user) {
            user = await storage.createUser({
              username: username,
              password: 'telegram-auth', // Default password for Telegram users
              telegramId: userId.toString(),
              phone: '',
              isAdmin: false
            });
          }
        } catch (error) {
          console.error('Error registering user:', error);
        }
      }

      const welcomeMessage = `🍽️ Welcome to FoodBot! 🍽️

Your favorite food delivery service right in Telegram!

🍕 Quick & Fresh Delivery
🚚 Track Your Orders  
💳 Easy Payment Options

Choose what you'd like to do:`;

      const keyboard = {
        inline_keyboard: [
          [
            { 
              text: '🛍️ Order Now', 
              web_app: { url: `${this.webAppUrl}?telegram_user=${userId}` }
            }
          ],
          [
            { text: '📋 View Menu', callback_data: 'view_menu' },
            { text: '📦 My Orders', callback_data: 'my_orders' }
          ],
          [
            { text: '📍 Share Location', callback_data: 'share_location' },
            { text: '❓ Help', callback_data: 'help' }
          ]
        ]
      };

      this.bot.sendMessage(chatId, welcomeMessage, {
        reply_markup: keyboard,
        parse_mode: 'HTML'
      });
    });

    // Menu command
    this.bot.onText(/\/menu/, async (msg) => {
      await this.showCategories(msg.chat.id);
    });

    // Orders command
    this.bot.onText(/\/orders/, async (msg) => {
      await this.showUserOrders(msg.chat.id, msg.from?.id?.toString());
    });

    // Help command
    this.bot.onText(/\/help/, (msg) => {
      const helpMessage = `🤖 FoodBot Help

Available Commands:
/start - Start ordering food
/menu - Browse food categories
/orders - View your order history
/help - Show this help message

🍽️ How to Order:
1. Tap "Order Now" to open our menu
2. Select your favorite items
3. Add delivery details
4. Choose payment method
5. Track your order!

📞 Support: Contact us anytime for help!`;

      this.bot.sendMessage(msg.chat.id, helpMessage);
    });

    // Callback query handler
    this.bot.on('callback_query', async (query) => {
      const chatId = query.message?.chat.id;
      const data = query.data;
      const userId = query.from.id.toString();

      if (!chatId) return;

      switch (data) {
        case 'view_menu':
          await this.showCategories(chatId);
          break;
        case 'my_orders':
          await this.showUserOrders(chatId, userId);
          break;
        case 'share_location':
          await this.requestLocation(chatId);
          break;
        case 'help':
          this.bot.onText(/\/help/, (msg) => this.bot.sendMessage(chatId, msg.text || ''));
          break;
        default:
          if (data?.startsWith('category_')) {
            const categoryId = parseInt(data.replace('category_', ''));
            await this.showCategoryItems(chatId, categoryId);
          }
      }

      this.bot.answerCallbackQuery(query.id);
    });

    // Location handler
    this.bot.on('location', (msg) => {
      const chatId = msg.chat.id;
      const location = msg.location;
      
      if (location) {
        this.bot.sendMessage(chatId, 
          `📍 Location received!\nLatitude: ${location.latitude}\nLongitude: ${location.longitude}\n\nYou can now use this location for delivery!`
        );
      }
    });

    // Error handler
    this.bot.on('polling_error', (error) => {
      console.error('Telegram bot polling error:', error);
    });
  }

  private async showCategories(chatId: number) {
    try {
      const categories = await storage.getCategories();
      
      const message = '🍽️ Food Categories\n\nChoose a category to browse:';
      
      const keyboard = {
        inline_keyboard: [
          ...categories.map((category: Category) => [
            { 
              text: `${category.icon} ${category.name}`, 
              callback_data: `category_${category.id}` 
            }
          ]),
          [
            { 
              text: '🛍️ Order Now (Full Menu)', 
              web_app: { url: this.webAppUrl }
            }
          ]
        ]
      };

      this.bot.sendMessage(chatId, message, { reply_markup: keyboard });
    } catch (error) {
      console.error('Error showing categories:', error);
      this.bot.sendMessage(chatId, 'Sorry, there was an error loading the menu. Please try again.');
    }
  }

  private async showCategoryItems(chatId: number, categoryId: number) {
    try {
      const items = await storage.getFoodItemsByCategory(categoryId);
      
      if (items.length === 0) {
        this.bot.sendMessage(chatId, 'No items available in this category right now.');
        return;
      }

      let message = '🍽️ Available Items:\n\n';
      
      items.forEach((item: FoodItem, index: number) => {
        message += `${index + 1}. *${item.name}*\n`;
        message += `   ${item.description}\n`;
        message += `   💰 $${item.price}\n`;
        message += `   ⏱️ ${item.deliveryTime}\n`;
        message += `   ⭐ ${item.rating}/5 (${item.reviewCount} reviews)\n\n`;
      });

      const keyboard = {
        inline_keyboard: [
          [
            { 
              text: '🛍️ Order These Items', 
              web_app: { url: `${this.webAppUrl}?category=${categoryId}` }
            }
          ],
          [
            { text: '🔙 Back to Categories', callback_data: 'view_menu' }
          ]
        ]
      };

      this.bot.sendMessage(chatId, message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    } catch (error) {
      console.error('Error showing category items:', error);
      this.bot.sendMessage(chatId, 'Sorry, there was an error loading the items. Please try again.');
    }
  }

  private async showUserOrders(chatId: number, telegramId?: string) {
    if (!telegramId) {
      this.bot.sendMessage(chatId, 'Please start the bot first with /start');
      return;
    }

    try {
      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) {
        this.bot.sendMessage(chatId, 'Please register first by using /start command.');
        return;
      }

      const orders = await storage.getOrdersByUser(user.id);
      
      if (orders.length === 0) {
        const message = '📦 No orders yet!\n\nStart ordering delicious food now:';
        const keyboard = {
          inline_keyboard: [
            [
              { 
                text: '🛍️ Order Now', 
                web_app: { url: this.webAppUrl }
              }
            ]
          ]
        };
        
        this.bot.sendMessage(chatId, message, { reply_markup: keyboard });
        return;
      }

      let message = '📦 Your Orders:\n\n';
      
      orders.slice(0, 5).forEach((order, index) => {
        const statusEmoji = this.getStatusEmoji(order.status);
        message += `${index + 1}. Order #${order.id}\n`;
        message += `   ${statusEmoji} ${order.status.toUpperCase()}\n`;
        message += `   💰 Total: $${order.total}\n`;
        message += `   📅 ${new Date(order.createdAt || '').toLocaleDateString()}\n\n`;
      });

      const keyboard = {
        inline_keyboard: [
          [
            { 
              text: '🛍️ Order Again', 
              web_app: { url: this.webAppUrl }
            }
          ]
        ]
      };

      this.bot.sendMessage(chatId, message, { reply_markup: keyboard });
    } catch (error) {
      console.error('Error showing user orders:', error);
      this.bot.sendMessage(chatId, 'Sorry, there was an error loading your orders. Please try again.');
    }
  }

  private async requestLocation(chatId: number) {
    const message = '📍 Share Your Location\n\nTo get accurate delivery estimates, please share your current location:';
    
    const keyboard = {
      keyboard: [
        [
          { 
            text: '📍 Share Location', 
            request_location: true 
          }
        ]
      ],
      resize_keyboard: true,
      one_time_keyboard: true
    };

    this.bot.sendMessage(chatId, message, { reply_markup: keyboard });
  }

  private getStatusEmoji(status: string): string {
    switch (status) {
      case 'pending': return '⏳';
      case 'confirmed': return '✅';
      case 'preparing': return '👨‍🍳';
      case 'on_the_way': return '🚚';
      case 'delivered': return '✅';
      case 'cancelled': return '❌';
      default: return '📋';
    }
  }

  // Method to send order confirmation to user
  public async sendOrderConfirmation(telegramId: string, orderId: number, total: string) {
    try {
      const user = await storage.getUserByTelegramId(telegramId);
      if (!user) return;

      const message = `✅ Order Confirmed!\n\nOrder #${orderId}\nTotal: $${total}\n\nYour delicious food is being prepared! 👨‍🍳\nEstimated delivery: 25-30 minutes`;
      
      const keyboard = {
        inline_keyboard: [
          [
            { text: '📍 Track Order', callback_data: `track_${orderId}` }
          ]
        ]
      };

      // Send to user's chat (you'll need to store chat IDs)
      // For now, this is a placeholder - you'd need to implement chat ID storage
      console.log('Order confirmation message:', message);
    } catch (error) {
      console.error('Error sending order confirmation:', error);
    }
  }

  // Method to send admin notification
  public async sendAdminNotification(orderId: number, customerInfo: any, items: any[]) {
    const adminMessage = `🚨 New Order Received!\n\nOrder #${orderId}\nCustomer: ${customerInfo.phone}\nAddress: ${customerInfo.address}\nPayment: ${customerInfo.paymentMethod}\n\nItems:\n${items.map(item => `• ${item.name} x${item.quantity}`).join('\n')}\n\nTotal: $${customerInfo.total}`;
    
    // Send to admin chat (you'll need to configure admin chat ID)
    console.log('Admin notification:', adminMessage);
  }
}

// Initialize bot if token is provided
let bot: FoodDeliveryBot | null = null;

export function initializeTelegramBot() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const webAppUrl = process.env.WEB_APP_URL || 'https://your-replit-app.replit.dev';
  
  if (token) {
    bot = new FoodDeliveryBot({ token, webAppUrl });
    console.log('Telegram bot initialized successfully');
    return bot;
  } else {
    console.log('TELEGRAM_BOT_TOKEN not found. Bot not initialized.');
    return null;
  }
}

export { bot };