import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertFoodItemSchema, insertOrderSchema, insertOrderItemSchema, insertCategorySchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG and WebP are allowed.'));
    }
  }
});

const orderCreateSchema = insertOrderSchema.extend({
  orderItems: z.array(insertOrderItemSchema.omit({ orderId: true }))
});

export function registerRoutes(app: Express): Server {
  // Setup authentication routes
  setupAuth(app);

  // Categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      res.status(400).json({ message: "Invalid category data" });
    }
  });

  // Food Items
  app.get("/api/food-items", async (req, res) => {
    try {
      const categoryId = req.query.categoryId;
      let foodItems;
      
      if (categoryId) {
        foodItems = await storage.getFoodItemsByCategory(Number(categoryId));
      } else {
        foodItems = await storage.getFoodItems();
      }
      
      res.json(foodItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch food items" });
    }
  });

  app.post("/api/food-items", upload.single('image'), async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    try {
      const foodItemData = insertFoodItemSchema.parse({
        ...req.body,
        imageUrl: req.file ? `/uploads/${req.file.filename}` : null
      });
      
      const foodItem = await storage.createFoodItem(foodItemData);
      res.status(201).json(foodItem);
    } catch (error) {
      res.status(400).json({ message: "Invalid food item data" });
    }
  });

  app.put("/api/food-items/:id", upload.single('image'), async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    try {
      const id = Number(req.params.id);
      const updateData = {
        ...req.body,
        ...(req.file && { imageUrl: `/uploads/${req.file.filename}` })
      };
      
      const foodItem = await storage.updateFoodItem(id, updateData);
      if (!foodItem) {
        return res.status(404).json({ message: "Food item not found" });
      }
      
      res.json(foodItem);
    } catch (error) {
      res.status(400).json({ message: "Invalid food item data" });
    }
  });

  app.delete("/api/food-items/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    try {
      const id = Number(req.params.id);
      const success = await storage.deleteFoodItem(id);
      if (!success) {
        return res.status(404).json({ message: "Food item not found" });
      }
      
      res.json({ message: "Food item deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete food item" });
    }
  });

  // Orders
  app.get("/api/orders", async (req, res) => {
    try {
      let orders;
      
      if (req.isAuthenticated()) {
        if (req.user.isAdmin) {
          orders = await storage.getOrders();
        } else {
          orders = await storage.getOrdersByUser(req.user.id);
        }
      } else {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const { orderItems, ...orderData } = orderCreateSchema.parse(req.body);
      
      // Calculate totals
      let subtotal = 0;
      for (const item of orderItems) {
        if (!item.foodItemId) {
          return res.status(400).json({ message: "Food item ID is required" });
        }
        const foodItem = await storage.getFoodItem(item.foodItemId);
        if (!foodItem) {
          return res.status(400).json({ message: `Food item ${item.foodItemId} not found` });
        }
        subtotal += Number(foodItem.price) * item.quantity;
        item.priceAtTime = foodItem.price;
      }
      
      const deliveryFee = Number(orderData.deliveryFee) || 2.50;
      const total = subtotal + deliveryFee;
      
      const orderToCreate = {
        ...orderData,
        userId: req.isAuthenticated() ? req.user.id : null,
        subtotal: subtotal.toString(),
        total: total.toString()
      };
      
      const order = await storage.createOrder(orderToCreate, orderItems);
      res.status(201).json(order);
    } catch (error) {
      console.error('Order creation error:', error);
      res.status(400).json({ message: "Invalid order data" });
    }
  });

  app.put("/api/orders/:id/status", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    try {
      const id = Number(req.params.id);
      const { status } = req.body;
      
      const order = await storage.updateOrderStatus(id, status);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to update order status" });
    }
  });

  // Favorites
  app.get("/api/favorites", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const favorites = await storage.getUserFavorites(req.user.id);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const { foodItemId } = req.body;
      const favorite = await storage.addFavorite({
        userId: req.user.id,
        foodItemId: Number(foodItemId)
      });
      res.status(201).json(favorite);
    } catch (error) {
      res.status(400).json({ message: "Failed to add favorite" });
    }
  });

  app.delete("/api/favorites/:foodItemId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const foodItemId = Number(req.params.foodItemId);
      const success = await storage.removeFavorite(req.user.id, foodItemId);
      if (!success) {
        return res.status(404).json({ message: "Favorite not found" });
      }
      
      res.json({ message: "Favorite removed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  // Statistics (Admin only)
  app.get("/api/stats", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    try {
      const stats = await storage.getOrderStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // CSV Export (Admin only)
  app.get("/api/orders/export", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    try {
      const orders = await storage.getOrders();
      
      // Convert to CSV
      const csvHeaders = ['Order ID', 'Customer Name', 'Phone', 'Address', 'Total', 'Status', 'Created At'];
      const csvRows = orders.map(order => [
        order.id,
        order.customerName || 'Guest',
        order.customerPhone,
        order.deliveryAddress,
        `$${order.total}`,
        order.status,
        order.createdAt?.toISOString().split('T')[0] || ''
      ]);
      
      const csvContent = [
        csvHeaders.join(','),
        ...csvRows.map(row => row.join(','))
      ].join('\n');
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=orders.csv');
      res.send(csvContent);
    } catch (error) {
      res.status(500).json({ message: "Failed to export orders" });
    }
  });

  // Telegram Webhook endpoint
  app.post("/api/telegram/webhook", async (req, res) => {
    try {
      // This endpoint would handle Telegram webhook updates
      // For now, just return OK
      res.status(200).json({ ok: true });
    } catch (error) {
      res.status(500).json({ message: "Webhook error" });
    }
  });

  // Telegram Mini App API endpoints
  app.get("/api/telegram/user/:telegramId", async (req, res) => {
    try {
      const telegramId = req.params.telegramId;
      const user = await storage.getUserByTelegramId(telegramId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // Create Telegram user
  app.post("/api/telegram/register", async (req, res) => {
    try {
      const { telegramId, username, firstName } = req.body;
      
      // Check if user already exists
      let user = await storage.getUserByTelegramId(telegramId);
      if (user) {
        return res.json(user);
      }
      
      // Create new user
      user = await storage.createUser({
        username: username || `telegram_${telegramId}`,
        password: 'telegram-auth',
        telegramId: telegramId,
        phone: '',
        isAdmin: false
      });
      
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: "Failed to register user" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static('uploads'));

  const httpServer = createServer(app);
  return httpServer;
}
