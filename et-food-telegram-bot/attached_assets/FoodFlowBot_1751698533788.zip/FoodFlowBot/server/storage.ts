import { 
  users, categories, foodItems, orders, orderItems, favorites,
  type User, type InsertUser, type Category, type InsertCategory,
  type FoodItem, type InsertFoodItem, type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem, type Favorite, type InsertFavorite
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByTelegramId(telegramId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category methods
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Food item methods
  getFoodItems(): Promise<FoodItem[]>;
  getFoodItemsByCategory(categoryId: number): Promise<FoodItem[]>;
  getFoodItem(id: number): Promise<FoodItem | undefined>;
  createFoodItem(foodItem: InsertFoodItem): Promise<FoodItem>;
  updateFoodItem(id: number, foodItem: Partial<InsertFoodItem>): Promise<FoodItem | undefined>;
  deleteFoodItem(id: number): Promise<boolean>;
  
  // Order methods
  getOrders(): Promise<(Order & { orderItems: (OrderItem & { foodItem: FoodItem })[] })[]>;
  getOrdersByUser(userId: number): Promise<(Order & { orderItems: (OrderItem & { foodItem: FoodItem })[] })[]>;
  getOrder(id: number): Promise<(Order & { orderItems: (OrderItem & { foodItem: FoodItem })[] }) | undefined>;
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Favorite methods
  getUserFavorites(userId: number): Promise<(Favorite & { foodItem: FoodItem })[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: number, foodItemId: number): Promise<boolean>;
  
  // Statistics
  getOrderStats(): Promise<{
    totalOrders: number;
    revenue: number;
    activeUsers: number;
    pendingOrders: number;
  }>;
  
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByTelegramId(telegramId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.telegramId, telegramId));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).where(eq(categories.isActive, true));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const [updated] = await db.update(categories)
      .set(category)
      .where(eq(categories.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db.update(categories)
      .set({ isActive: false })
      .where(eq(categories.id, id));
    return result.rowCount > 0;
  }

  async getFoodItems(): Promise<FoodItem[]> {
    return await db.select().from(foodItems).where(eq(foodItems.isAvailable, true));
  }

  async getFoodItemsByCategory(categoryId: number): Promise<FoodItem[]> {
    return await db.select().from(foodItems)
      .where(and(eq(foodItems.categoryId, categoryId), eq(foodItems.isAvailable, true)));
  }

  async getFoodItem(id: number): Promise<FoodItem | undefined> {
    const [item] = await db.select().from(foodItems).where(eq(foodItems.id, id));
    return item || undefined;
  }

  async createFoodItem(foodItem: InsertFoodItem): Promise<FoodItem> {
    const [newItem] = await db.insert(foodItems).values(foodItem).returning();
    return newItem;
  }

  async updateFoodItem(id: number, foodItem: Partial<InsertFoodItem>): Promise<FoodItem | undefined> {
    const [updated] = await db.update(foodItems)
      .set(foodItem)
      .where(eq(foodItems.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteFoodItem(id: number): Promise<boolean> {
    const result = await db.update(foodItems)
      .set({ isAvailable: false })
      .where(eq(foodItems.id, id));
    return result.rowCount > 0;
  }

  async getOrders(): Promise<(Order & { orderItems: (OrderItem & { foodItem: FoodItem })[] })[]> {
    return await db.query.orders.findMany({
      orderBy: [desc(orders.createdAt)],
      with: {
        orderItems: {
          with: {
            foodItem: true
          }
        }
      }
    });
  }

  async getOrdersByUser(userId: number): Promise<(Order & { orderItems: (OrderItem & { foodItem: FoodItem })[] })[]> {
    return await db.query.orders.findMany({
      where: eq(orders.userId, userId),
      orderBy: [desc(orders.createdAt)],
      with: {
        orderItems: {
          with: {
            foodItem: true
          }
        }
      }
    });
  }

  async getOrder(id: number): Promise<(Order & { orderItems: (OrderItem & { foodItem: FoodItem })[] }) | undefined> {
    const order = await db.query.orders.findFirst({
      where: eq(orders.id, id),
      with: {
        orderItems: {
          with: {
            foodItem: true
          }
        }
      }
    });
    return order || undefined;
  }

  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    
    const orderItemsWithOrderId = items.map(item => ({
      ...item,
      orderId: newOrder.id
    }));
    
    await db.insert(orderItems).values(orderItemsWithOrderId);
    return newOrder;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const [updated] = await db.update(orders)
      .set({ status, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return updated || undefined;
  }

  async getUserFavorites(userId: number): Promise<(Favorite & { foodItem: FoodItem })[]> {
    return await db.query.favorites.findMany({
      where: eq(favorites.userId, userId),
      with: {
        foodItem: true
      }
    });
  }

  async addFavorite(favorite: InsertFavorite): Promise<Favorite> {
    const [newFavorite] = await db.insert(favorites).values(favorite).returning();
    return newFavorite;
  }

  async removeFavorite(userId: number, foodItemId: number): Promise<boolean> {
    const result = await db.delete(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.foodItemId, foodItemId)));
    return result.rowCount > 0;
  }

  async getOrderStats(): Promise<{
    totalOrders: number;
    revenue: number;
    activeUsers: number;
    pendingOrders: number;
  }> {
    const [stats] = await db.select({
      totalOrders: sql<number>`count(*)`,
      revenue: sql<number>`sum(${orders.total})`,
      pendingOrders: sql<number>`sum(case when ${orders.status} = 'pending' then 1 else 0 end)`
    }).from(orders);

    const [userStats] = await db.select({
      activeUsers: sql<number>`count(distinct ${orders.userId})`
    }).from(orders);

    return {
      totalOrders: stats.totalOrders || 0,
      revenue: Number(stats.revenue) || 0,
      activeUsers: userStats.activeUsers || 0,
      pendingOrders: stats.pendingOrders || 0
    };
  }
}

export const storage = new DatabaseStorage();
