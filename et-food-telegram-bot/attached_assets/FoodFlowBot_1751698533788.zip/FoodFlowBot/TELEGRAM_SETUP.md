# Telegram Bot Setup Guide

This guide will help you set up the Telegram food delivery bot integration with your Replit application.

## Prerequisites

1. A Telegram account
2. Your Replit application running (this project)
3. Basic understanding of environment variables

## Step 1: Create a Telegram Bot

1. Open Telegram and search for `@BotFather`
2. Start a conversation with BotFather by sending `/start`
3. Create a new bot by sending `/newbot`
4. Choose a name for your bot (e.g., "FoodBot Delivery")
5. Choose a username for your bot (must end with 'bot', e.g., "yourname_foodbot")
6. BotFather will provide you with a **Bot Token** - save this token securely

## Step 2: Configure Environment Variables

1. In your Replit project, go to the **Secrets** tab (lock icon in sidebar)
2. Add the following environment variables:

```
TELEGRAM_BOT_TOKEN=your_bot_token_here
WEB_APP_URL=https://your-replit-app-domain.replit.dev
SESSION_SECRET=your_random_session_secret_here
```

### How to get your values:

- **TELEGRAM_BOT_TOKEN**: The token you received from BotFather
- **WEB_APP_URL**: Your Replit app's public URL (found in the webview)
- **SESSION_SECRET**: Generate a random string (at least 32 characters)

## Step 3: Set Up Mini Web App

1. Go back to BotFather in Telegram
2. Send `/mybots` and select your bot
3. Click "Bot Settings" → "Menu Button"
4. Set the menu button URL to: `https://your-replit-app-domain.replit.dev/telegram`
5. Set the menu button text to: "Order Food 🍽️"

## Step 4: Configure Bot Commands

Send these commands to BotFather (replace `@yourbotname` with your actual bot username):

```
/setcommands

start - Start ordering food
menu - View food menu  
orders - View your order history
help - Get help and support
```

## Step 5: Test Your Bot

1. Search for your bot in Telegram using its username
2. Send `/start` to your bot
3. You should see a welcome message with inline buttons
4. Click "Order Now" to open the mini web app
5. Test placing an order through the interface

## Step 6: Admin Setup

1. Go to your web app: `https://your-replit-app-domain.replit.dev`
2. Register an admin account or use existing credentials
3. Navigate to `/admin` to access the admin dashboard
4. Add food categories and menu items
5. Monitor orders and manage the system

## Features Available

### For Customers:
- `/start` - Welcome message with quick actions
- `/menu` - Browse food categories via bot
- `/orders` - View order history  
- `/help` - Get support information
- **Mini Web App** - Full ordering interface in Telegram
- **Location Sharing** - Share delivery location
- **Payment Options** - Cash on Delivery or Telebirr

### For Admins:
- **Admin Dashboard** - Manage orders, menu items, and users
- **Order Management** - Update order status, view details
- **Menu Management** - Add/edit food items and categories
- **CSV Export** - Export order data
- **Real-time Statistics** - View business metrics

## Troubleshooting

### Bot Not Responding
1. Check that `TELEGRAM_BOT_TOKEN` is correctly set in Secrets
2. Restart your Replit application
3. Verify the token with BotFather using `/token`

### Mini Web App Not Loading
1. Ensure `WEB_APP_URL` matches your Replit domain exactly
2. Check that the `/telegram` route is accessible in your browser
3. Verify the menu button URL in BotFather settings

### Orders Not Working
1. Confirm database is connected (check console logs)
2. Test the web interface first at the main URL
3. Check that food items and categories are added via admin panel

### Permission Issues
1. Ensure admin users have `is_admin` set to `true` in database
2. Check authentication is working on the web interface
3. Verify session configuration is correct

## Advanced Configuration

### Webhook Setup (Optional)
For production environments, you can set up webhooks instead of polling:

1. Set up HTTPS endpoint: `/api/telegram/webhook`
2. Configure webhook with Telegram API
3. Update bot initialization to use webhooks instead of polling

### Custom Domain (Optional)
1. Set up a custom domain in Replit
2. Update `WEB_APP_URL` to use your custom domain
3. Update BotFather menu button URL accordingly

## Support

If you encounter issues:

1. Check the Replit console logs for errors
2. Verify all environment variables are set correctly  
3. Test each component individually (web app, bot commands, mini app)
4. Ensure your Replit app is always running

## Security Notes

- Never share your bot token publicly
- Use strong session secrets
- Regularly monitor bot activity
- Implement rate limiting for production use

## Next Steps

Once your bot is working:

1. Customize the menu items and categories
2. Set up payment processing (if using real payments)
3. Configure delivery zones and fees
4. Add more bot commands as needed
5. Monitor and optimize performance

Your Telegram food delivery bot is now ready to accept orders!